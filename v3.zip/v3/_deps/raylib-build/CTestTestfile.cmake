# CMake generated Testfile for 
# Source directory: C:/Users/User/Desktop/WiWiWi/Old/build/_deps/raylib-src
# Build directory: C:/Users/User/Desktop/WiWiWi/RagdollLab_v2/build/v3/_deps/raylib-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("raylib")
