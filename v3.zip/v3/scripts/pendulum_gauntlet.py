import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

gantry = lab.spawn_box(0.0, 11.5, 22.0, 0.7, material="steel", static=True)

for idx, gx in enumerate([-5.5, 0.0, 5.5]):
    offset_x = 3.8 if (idx % 2 == 0) else -3.8
    ball = lab.spawn_circle(gx + offset_x, 7.2, 0.85, material="steel")
    lab.connect_rod(gantry, ball, ax=gx, ay=-0.35, bx=0.0, by=0.0)

for sx, spd in [(-2.75, 22.0), (2.75, -22.0)]:
    ped = lab.spawn_box(sx, 0.9, 0.6, 1.8, material="concrete", static=True)
    saw = lab.spawn_saw(sx, 2.1, radius=1.05, speed=spd)
    lab.connect_hinge(ped, saw, sx, 2.1, motor_speed=spd, max_torque=2500.0)

plate_l = lab.spawn_sensor(-8.0, 0.15, kind="plate")
barrel_l = lab.spawn_barrel(-8.0, 1.2)
lab.wire(plate_l, barrel_l)

plate_r = lab.spawn_sensor(8.0, 0.15, kind="plate")
barrel_r = lab.spawn_barrel(8.0, 1.2)
lab.wire(plate_r, barrel_r)

lab.spawn_ragdoll(-9.8, 1.8, active=True, roaming=True)
lab.spawn_ragdoll(9.8, 1.8, active=True, roaming=True)
