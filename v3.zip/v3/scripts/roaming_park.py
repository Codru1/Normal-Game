import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

# Acid vat pit in the center, hollow wood shelter on left, armed hostile & roaming humans!
lab.spawn_acid(0.0, 0.85, w=4.4, h=1.7)
lab.spawn_box(-2.45, 0.85, 0.5, 1.7, material="concrete", static=True)
lab.spawn_box(2.45, 0.85, 0.5, 1.7, material="concrete", static=True)

# Hollow wood house on the left
house = lab.spawn_box(-8.5, 1.6, 3.2, 3.2, material="wood", hollow=True)
lab.spawn_box(-8.5, 1.2, 0.8, 0.8, material="rubber")

# Roaming humans + hostile knife/gun duelers
h1 = lab.spawn_ragdoll(-5.0, 1.6, active=True, roaming=True)
h2 = lab.spawn_ragdoll(5.0, 1.6, active=True, roaming=True, hostile=True, weapon="knife")
h3 = lab.spawn_ragdoll(10.0, 1.6, active=True, roaming=True, hostile=True, weapon="gun")

# Attach C4 to the hollow house; press E to detonate
lab.spawn_c4(-8.5, 3.1, attach_id=house)
