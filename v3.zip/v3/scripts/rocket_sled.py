import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

chassis = lab.spawn_box(-14.0, 1.25, 4.8, 0.35, material="steel")
wheel_back = lab.spawn_circle(-15.7, 0.65, 0.6, material="rubber")
wheel_front = lab.spawn_circle(-12.3, 0.65, 0.6, material="rubber")
lab.connect_hinge(chassis, wheel_back, -15.7, 0.65)
lab.connect_hinge(chassis, wheel_front, -12.3, 0.65)

post_back = lab.spawn_box(-15.3, 2.4, 0.25, 2.0, material="steel")
post_front = lab.spawn_box(-12.7, 2.4, 0.25, 2.0, material="steel")
roof = lab.spawn_box(-14.0, 3.45, 2.9, 0.25, material="steel")
lab.connect_weld(chassis, post_back)
lab.connect_weld(chassis, post_front)
lab.connect_weld(post_back, roof)
lab.connect_weld(post_front, roof)

lab.spawn_ragdoll(-14.0, 2.35, active=True)

thruster_low = lab.spawn_thruster(-16.6, 1.25, 0.0, force=2400.0)
thruster_high = lab.spawn_thruster(-15.7, 2.3, 0.0, force=2000.0)
lab.connect_weld(chassis, thruster_low)
lab.connect_weld(post_back, thruster_high)

ignition = lab.spawn_sensor(-18.0, 0.3, kind="timer", interval=0.35)
lab.wire(ignition, thruster_low)
lab.wire(ignition, thruster_high)

lab.spawn_box(10.0, 1.6, 1.1, 3.2, material="concrete", static=True)
lab.spawn_box(11.6, 2.0, 0.35, 4.0, material="glass")
lab.spawn_barrel(12.8, 0.8)
lab.spawn_barrel(12.8, 2.2)
lab.spawn_box(14.2, 2.0, 0.8, 4.0, material="wood")
