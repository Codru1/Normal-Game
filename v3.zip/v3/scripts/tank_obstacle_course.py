import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

lab.spawn_tank(-10.0, 0.05)
for x in (-4.0, 1.0, 6.0):
    lab.spawn_box(x, 0.18, 1.6, 0.24, material="concrete", static=True)
    for row in range(3):
        lab.spawn_box(x + 0.65, 0.62 + row * 0.58, 0.55, 0.55, material="wood")

for x in (9.0, 11.0, 13.0):
    lab.spawn_box(x, 1.0, 0.2, 1.9, material="glass")

