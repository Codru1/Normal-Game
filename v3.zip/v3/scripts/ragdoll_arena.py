import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

cliff_l = lab.spawn_box(-11.5, 2.5, 6.0, 5.0, material="concrete", static=True)
cliff_r = lab.spawn_box(11.5, 2.5, 6.0, 5.0, material="concrete", static=True)

planks = []
num_planks = 8
start_x = -7.0
step_x = 2.0
for i in range(num_planks):
    px = start_x + i * step_x
    p = lab.spawn_box(px, 4.85, 1.85, 0.32, material="wood")
    planks.append(p)

lab.connect_hinge(cliff_l, planks[0], -8.0, 4.85)
for i in range(num_planks - 1):
    joint_x = start_x + i * step_x + 1.0
    lab.connect_hinge(planks[i], planks[i + 1], joint_x, 4.85)
lab.connect_hinge(planks[-1], cliff_r, 8.0, 4.85)

for sx, spd in [(-4.2, 24.0), (0.0, -26.0), (4.2, 24.0)]:
    ped = lab.spawn_box(sx, 0.7, 0.5, 1.4, material="steel", static=True)
    saw = lab.spawn_saw(sx, 1.6, radius=1.15, speed=spd)
    lab.connect_hinge(ped, saw, sx, 1.6, motor_speed=spd, max_torque=3000.0)

tesla_l = lab.spawn_tesla(-7.2, 0.8)
tesla_r = lab.spawn_tesla(7.2, 0.8)
pulse_timer = lab.spawn_sensor(0.0, 10.5, kind="timer", interval=1.8)
lab.wire(pulse_timer, tesla_l)
lab.wire(pulse_timer, tesla_r)

lab.spawn_ragdoll(-2.8, 6.4, active=True)
lab.spawn_ragdoll(2.8, 6.4, active=True)
