import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

for index in range(7):
    x = (index - 3) * 2.2
    rocket = lab.spawn_firework(x, 0.4)
    timer = lab.spawn_sensor(x, 0.0, kind="timer", interval=0.25 + index * 0.25)
    lab.wire(timer, rocket)

