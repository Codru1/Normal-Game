import lab

lab.clear()
lab.set_gravity(0.0, -9.81)

lab.spawn_ragdoll(-3.0, 1.45, active=True, roaming=True)
lab.spawn_ragdoll(3.0, 1.45, active=True, hostile=True)
lab.spawn_ragdoll(0.0, 4.1, active=False)
lab.spawn_box(0.0, 2.5, 2.2, 0.2, material="glass")

for x in (-3.0, 0.0, 3.0):
    lab.spawn_barrel(x + 0.9, 0.55)

