import lab

lab.clear()
lab.set_gravity(0.0, -9.81)
lab.set_time_scale(1.0)

pivot_x, pivot_y = -6.0, 2.4
base = lab.spawn_box(pivot_x, 1.2, 1.5, 2.4, material="concrete", static=True)
arm = lab.spawn_box(pivot_x - 1.0, pivot_y, 6.4, 0.30, material="wood")
lab.connect_hinge(base, arm, pivot_x, pivot_y, motor_speed=-5.0, max_torque=300.0,
                  lower_angle=-0.72, upper_angle=0.01)

# The rear lip keeps the loose ball on the arm while it starts to swing.
lip = lab.spawn_box(-10.05, 2.65, 0.25, 0.45, material="wood")
lab.connect_weld(arm, lip, no_collision=True)
lab.spawn_circle(-9.45, 3.0, 0.45, material="steel")

# The glass face is the target, with a barrel and stacked props behind it.
lab.spawn_box(4.0, 2.9, 0.22, 5.8, material="glass")
lab.spawn_box(5.7, 1.5, 0.45, 3.0, material="wood")
lab.spawn_box(7.6, 1.5, 0.45, 3.0, material="wood")
lab.spawn_box(6.65, 3.2, 2.7, 0.35, material="wood")
lab.spawn_barrel(6.65, 3.9)

